package com.idea.mmh.common.interceptor;

public class LoginInterceptor {
	
	

}
