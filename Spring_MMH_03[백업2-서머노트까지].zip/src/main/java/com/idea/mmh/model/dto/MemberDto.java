package com.idea.mmh.model.dto;

public class MemberDto {

}
