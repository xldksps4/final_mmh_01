$(function() {

	// join 버튼 눌렀을때 다시 들어가는 기능
	$("#backBtn").click(function() {
		$("#signUpPage").animate({
			'left' : "-=100%"
		});
	});

});